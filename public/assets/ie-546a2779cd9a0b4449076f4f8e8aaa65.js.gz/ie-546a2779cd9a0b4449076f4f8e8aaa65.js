(function() {
  $(".section[data-anchor=secondPage]").createElement('video');

}).call(this);
